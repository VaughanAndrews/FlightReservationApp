package com.example.vaughan.airlinereservation;

public class PersonSchema {
    public static final String Name = "PERSON";

    public static final class Attributes{
        public static final String userName = "username";
        public static final String password = "password";
        public static final String UUID = "uuid";
    }
}
